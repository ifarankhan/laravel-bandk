<?php
/**
 * Created by PhpStorm.
 * User: fara
 * Date: 8/1/2018
 * Time: 12:10 AM
 */

namespace App\Repositories;

interface ClaimMechanicsInterface
{
    public function all();
}