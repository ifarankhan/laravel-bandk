<?php
/**
 * Created by PhpStorm.
 * User: fara
 * Date: 8/1/2018
 * Time: 12:13 AM
 */

namespace App\Repositories;

interface DepartmentsInterface
{
    public function all();
}