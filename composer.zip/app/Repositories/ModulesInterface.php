<?php
/**
 * Created by PhpStorm.
 * User: fara
 * Date: 8/3/2018
 * Time: 11:54 PM
 */

namespace App\Repositories;

interface ModulesInterface
{
    public function all();
}