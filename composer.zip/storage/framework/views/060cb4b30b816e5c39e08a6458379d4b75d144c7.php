<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(getTranslation('dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('customer.index')); ?>"><?php echo e(getTranslation('customer')); ?></a></li>
    </ul>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Create Customer </h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">

                    <br />
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(route('customer.store')); ?>" method="POST" enctype='multipart/form-data'>
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo e(getTranslation('customer_name')); ?> <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="name" class="form-control col-md-7 col-xs-12" name="name" value="<?php echo e(old('name')); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address"><?php echo e(getTranslation('customer_address')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="address" class="form-control col-md-7 col-xs-12" name="address" value="<?php echo e(old('address')); ?>">
                                <?php if($errors->has('address')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="zip_code"> <?php echo e(getTranslation('customer_zip_code')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="zip_code" class="form-control col-md-7 col-xs-12" name="zip_code" value="<?php echo e(old('zip_code')); ?>">
                                <?php if($errors->has('zip_code')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('zip_code')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="city"><?php echo e(getTranslation('customer_city')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="city" class="form-control col-md-7 col-xs-12" name="city" value="<?php echo e(old('city')); ?>">
                                <?php if($errors->has('city')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="contact_person"> <?php echo e(getTranslation('customer_contact_person')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="contact_person" class="form-control col-md-7 col-xs-12" name="contact_person" value="<?php echo e(old('contact_person')); ?>">
                                <?php if($errors->has('contact_person')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('contact_person')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="bank_number"> <?php echo e(getTranslation('customer_bank_number')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="bank_number" class="form-control col-md-7 col-xs-12" name="bank_number" value="<?php echo e(old('bank_number')); ?>">
                                <?php if($errors->has('bank_number')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('bank_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="account_number"> <?php echo e(getTranslation('customer_account_number')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="account_number" class="form-control col-md-7 col-xs-12" name="account_number" value="<?php echo e(old('account_number')); ?>">
                                <?php if($errors->has('account_number')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('account_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="insurance_company_name"> <?php echo e(getTranslation('customer_insurance_company_name')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="insurance_company_name" class="form-control col-md-7 col-xs-12" name="insurance_company_name" value="<?php echo e(old('insurance_company_name')); ?>">
                                <?php if($errors->has('insurance_company_name')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('insurance_company_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="policy_number"> <?php echo e(getTranslation('customer_policy_number')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="policy_number" class="form-control col-md-7 col-xs-12" name="policy_number" value="<?php echo e(old('policy_number')); ?>">
                                <?php if($errors->has('policy_number')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('policy_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="shared_link"> <?php echo e(getTranslation('shared_link')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="shared_link" class="form-control col-md-7 col-xs-12" name="shared_link" value="<?php echo e(old('shared_link')); ?>">
                                <?php if($errors->has('shared_link')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('shared_link')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="logo">Logo
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="file" name="logo" >
                                <?php if($errors->has('logo')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('logo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="is_send_email" > <?php echo e(getTranslation('receive_emails')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="checkbox" name="is_send_email" id="is_send_email" value="true" >
                                <?php if($errors->has('bnk_insurance_number')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('bnk_insurance_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo e(getTranslation('customer_emails')); ?>

                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <div class="col-md-9" id="emails_div">
                                    <?php if(count(old('emails')) > 0): ?>
                                        <?php $__currentLoopData = old('emails'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="margin-bottom: 35px;">
                                                <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="emails[]" value="<?php echo e($email); ?>">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-3">
                                    <button class="btn btn-danger pull-right" type="button" id="add_emails"><?php echo e(getTranslation('customer_add_emails')); ?></button>
                                </div>

                            </div>
                        </div>
                        <br />
                        <br />
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <a class="btn btn-danger" href="<?php echo e(route('customer.index')); ?>">Back</a>
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/vendors/select2/dist/css/select2.min.css')); ?> " rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script>
        jQuery(document).ready(function(){
           jQuery("#roles").on('change', function(){
                var value = jQuery(this).val();

                if(jQuery.inArray("2", value) !== -1) {
                    jQuery("#department_id_div").show();
                    jQuery("#department_id").prop( "disabled", false );
                } else {
                    jQuery("#department_id_div").hide();
                    jQuery("#department_id").prop( "disabled", true );
                }
           });
        });
        $('.select2').select2();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>