<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <?php if(!in_array('AGENT', getUserRoles(\Auth::user()))): ?>
            <li><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(getTranslation('dashboard')); ?></a></li>
        <?php endif; ?>
        <li><a href="<?php echo e(route('claim.index')); ?>"><?php echo e(getTranslation('claims')); ?></a></li>
    </ul>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Claims Lists</h2>
                    <a href="<?php echo e(route('claim.create')); ?>" class="btn btn-danger pull-right">Opret</a>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="flash-message">
                        <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has('alert-' . $msg)): ?>
                                <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if(in_array('AGENT', getUserRoles(\Auth::user())) && \Auth::user()->customer): ?>
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="mt-element-ribbon bg-grey-steel">
                                    <table class="table table-responsive table-noborder">
                                        <tbody>
                                        <tr>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_name')); ?>:</strong></div>
                                                <div class="col-md-6"> <?php echo e(\Auth::user()->customer->name); ?></div>
                                            </td>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_contact_person')); ?>:</strong></div>
                                                <div class="col-md-6"><?php echo e(\Auth::user()->customer->contact_person); ?></div>
                                            </td>
                                            <td>
                                                <div class="col-md-6"><strong>Selskab:</strong></div>
                                                <div class="col-md-6"><?php echo e((\Auth::user()->customer) ? \Auth::user()->customer->insurance_company_name : ''); ?></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('address_1')); ?>:</strong> </div>
                                                <div class="col-md-6"><?php echo e((\Auth::user()->customer->address)  ? \Auth::user()->customer->address : ''); ?></div>
                                                </td>
                                            <td>&nbsp;</td>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_policy_number')); ?>:</strong> </div>
                                                <div class="col-md-6"><?php echo e((\Auth::user()->customer)  ? \Auth::user()->customer->policy_number : ''); ?></div>
                                                </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_zip_code')); ?>:</strong> </div>
                                                <div class="col-md-6"><?php echo e((\Auth::user()->customer)  ? \Auth::user()->customer->zip_code : ''); ?></div>
                                                </td>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_emails')); ?>:</strong> </div>
                                                <div class="col-md-6"><?php echo (\Auth::user()->customer && \Auth::user()->customer->emails)  ? implode('<br /> ', json_decode(\Auth::user()->customer->emails, true)) : ''; ?></div>
                                                </td>
                                            <td>&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_city')); ?>:</strong> </div>
                                                <div class="col-md-6"><?php echo e((\Auth::user()->customer) ? \Auth::user()->customer->city : ''); ?></div>
                                                </td>
                                            <td>&nbsp;</td>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_bank_number')); ?>:</strong> </div>
                                                <div class="col-md-6"><?php echo e((\Auth::user()->customer) ? \Auth::user()->customer->bank_number : ''); ?></div>
                                                </td>
                                        </tr>
                                        <tr>
                                            <td>&nbsp;</td>
                                            <td>&nbsp;</td>
                                            <td>
                                                <div class="col-md-6"><strong><?php echo e(getTranslation('customer_account_number')); ?>:</strong> </div>
                                                <div class="col-md-6"><?php echo e((\Auth::user()->customer) ? \Auth::user()->customer->account_number : ''); ?></div>
                                                </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('claim.index')); ?>" method="GET">
                         <div class="row">
                            <div class="form-group form-group-sm col-md-12 col-lg-12">
                                <div class="row">
                                    <div class="col-md-4 col-lg-4">
                                        <label for="claim_type_id">
                                            <?php echo e(getTranslation('claim_type')); ?>

                                        </label>
                                        <select id="claim_type_id" class="form-control" name="search[claim_type_id]" data-actions-box="true" tabindex="-1" aria-hidden="true">
                                            <option value=""><?php echo e(getTranslation('select_claim_type')); ?></option>
                                            <?php $__currentLoopData = $claimTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claimType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($claimType->id); ?>" <?php echo e(($search && isset($search['claim_type_id'])&& $search['claim_type_id'] == $claimType->id) ? 'selected="selected"' : ''); ?>><?php echo e($claimType->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4 col-lg-4">
                                        <label for="type_of_document">
                                            <?php echo e(getTranslation('claim_creation_date')); ?>

                                        </label>
                                        <div class="input-group date" id="date">
                                            <input type="text" class="form-control" name="search[date]" id="date" value="<?php echo e(($search && isset($search['date'])) ? $search['date'] : ''); ?>">
                                            <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-lg-4">
                                        <label for="department_id">
                                            <?php echo e(getTranslation('department')); ?>

                                        </label>
                                        <select id="department_id" class="form-control" name="search[department_id]" tabindex="-1" aria-hidden="true">
                                            <option value=""><?php echo e(getTranslation('select_department')); ?></option>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($department->id); ?>" <?php echo e(($search && isset($search['department_id']) && $search['department_id'] == $department->id) ? 'selected="selected"' : ''); ?>><?php echo e($department->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 col-lg-4">
                                        <label for="selsskab_skade_nummer">
                                            Selskab skade nummer
                                        </label>
                                        <input type="text" class="form-control" name="search[selsskab_skade_nummer]" id="selsskab_skade_nummer" value="<?php echo e(($search && isset($search['selsskab_skade_nummer'])) ? $search['selsskab_skade_nummer'] : ''); ?>">
                                    </div>
                                    

                                    <?php if(!in_array('AGENT', getUserRoles(\Auth::user()))): ?>
                                        <div class="col-md-4 col-lg-4">
                                            <label for="customer_id">
                                                <?php echo e(getTranslation('customer')); ?>

                                            </label>
                                            <select id="customer_id" class="form-control" name="search[customer_id]" tabindex="-1" aria-hidden="true">
                                                <option value=""><?php echo e(getTranslation('select_customer')); ?></option>
                                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($customer->id); ?>" <?php echo e((session('customer_id') && session('customer_id') == $customer->id) ? 'selected="selected"' : ''); ?>><?php echo e($customer->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-md-4 col-lg-4">
                                        <label for="id">
                                            <?php echo e(getTranslation('claim_id')); ?>

                                        </label>
                                        <input type="text" class="form-control" name="search[id]" id="id" value="<?php echo e(($search && isset($search['id'])) ? $search['id'] : ''); ?>">
                                    </div>

                                </div>
                            </div>
                         </div>
                        <div class="row">
                            <div class="form-group form-group-sm">
                                <div class="col-md-4 col-lg-4">
                                    <button class="btn btn-danger" type="submit"><?php echo e(getTranslation('submit')); ?></button>
                                </div>
                                <div class="col-md-4 col-lg-4">
                                    <label for="status">
                                        <?php echo e(getTranslation('get_closed_claims_as_well')); ?>

                                        <input type="checkbox" id="status" name="search[status]" value="CLOSED" <?php echo e(($search && isset($search['status'])) ? 'checked="checked"' : ''); ?>>
                                    </label>
                                    <br />
                                </div>
                            </div>
                        </div>
                    </form>
                    <br />
                    <br />
                    <table id="datatable" class="table table-bordered">
                        <thead>
                        <tr>
                            <th><?php echo e(getTranslation('date')); ?></th>
                            <th><?php echo e(getTranslation('customer_name')); ?></th>
                            <th>Virksomheder</th>
                            <th><?php echo e(getTranslation('claim_id')); ?></th>

                            <th>Selskab skade nummer</th>
                            <th><?php echo e(getTranslation('claim_type')); ?></th>
                            <th><?php echo e(getTranslation('department')); ?></th>
                            <th><?php echo e(getTranslation('address_1')); ?></th>
                            <th><?php echo e(getTranslation('address_2')); ?></th>
                            <th><?php echo e(getTranslation('actions')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="alert alert-<?php echo e(getClaimColor($claim)); ?>" id="claim_<?php echo e($claim->id); ?>">
                                <td data-sort="<?php echo e(date('Y-m-d', strtotime($claim->date))); ?>"><?php echo e($claim->date); ?></td>
                                <td><?php echo e(($claim->customer && $claim->customer->name)  ? $claim->customer->name : ''); ?></td>
                                <td>
                                    <?php echo e(($claim->department && $claim->department->company && $claim->department->company->name)  ? $claim->department->company->name : ''); ?>

                                </td>
                                <td >
                                    <?php echo e($claim->id); ?>

                                </td>

                                <td><?php echo e($claim->selsskab_skade_nummer); ?></td>
                                <td><?php echo e(($claim->type) ? $claim->type->name : ''); ?></td>
                                
                                <td><?php echo e(($claim->department) ? $claim->department->name : ''); ?></td>
                                <td><?php echo e(($claim->address1)  ? $claim->address1->address : ''); ?></td>
                                <td><?php echo e(($claim->address_2)  ? $claim->address_2 : ''); ?></td>
                                <td>
                                    <a href="<?php echo e(route('claim.details', ['id'=> $claim->id])); ?>" class="btn btn-success btn-sm"><?php echo e(getTranslation('details')); ?></a>
                                    <?php if(isAdmin(\Auth::user())): ?>
                                        <a href="<?php echo e(route('claim.edit', ['id'=> $claim->id])); ?>" class="btn btn-info btn-sm"><?php echo e(getTranslation('edit')); ?></a>
                                        <button data-url="<?php echo e(route('claim.delete', ['id'=> $claim->id])); ?>" data-id="<?php echo e($claim->id); ?>" class="btn btn-danger btn-sm delete" data-csrf="<?php echo e(csrf_token()); ?>"><?php echo e(getTranslation('delete')); ?></button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.print.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-scroller/js/dataTables.scroller.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script>
        $('#date').datetimepicker({
            format: 'YYYY-MM-DD'
        });

        $('.delete').on('click', function(event){
            event.stopImmediatePropagation();
            var modal = $("#modal-delete");
            var url = $(this).data('url');
            var id = $(this).data('id');
            var csrf = $(this).data('csrf');
            modal.modal('show');

            $("#delete-confirm").unbind().on('click', function (e) {
                e.stopImmediatePropagation();
                sendAjax(url, {_token: csrf}, 'POST', function (result) {
                    modal.modal('hide');
                    if(result.is_deleted) {
                        $("#claim_"+id).hide('slow');
                    }
                });
            });
        });
        $('#datatable').on( 'dblclick', 'tbody td.estimate_value', function (e) {
            var element = $(this);

            var claimId = element.attr('data-claim-id');

            var url = element.attr('data-url');
            var csrf = element.attr('data-csrf');
            var html = element.html().trim();

            var index = html.indexOf('<textarea type="text"');

            if(index === -1) {
                var input = '<textarea type="text" name="updated-value" class="form-control update-value-'+claimId+'" data-claim-id="'+claimId+'">'+html+'</textarea>';

                $(this).html(input);

                $(".update-value-"+claimId).on('blur', element, function (e) {
                    var updatedText = $(this).val();
                    var  data = {_token: csrf, id: claimId, estimate: updatedText};

                    if(updatedText != html && updatedText.trim() != '') {
                        sendAjax(url, data, 'POST',function (result) {
                        });
                    }

                    //updatedText = formatNumber(updatedText);
                    element.html(updatedText);

                });
                $(".update-value-"+claimId).on('change', element, function (event) {
                    console.log('hello')
                    var updatedText = $(this).val();
                    updatedText = formatNumber(updatedText);

                    $(this).val(updatedText);
                });
            }
        });


        function formatNumber(x) {
            x = x.replace('.', '');
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>