<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>B&k!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('frontend/css/custom.css')); ?>" rel="stylesheet" type="text/css">
    <style>
        .main-header-active {
            background: #f37522 !important;
            transition: all 0.3s ease;
            -o-transition: all 0.3s ease;
            -moz-transition: all 0.3s ease;
            -webkit-transition: all 0.3s ease;
        }
    </style>
    <script>
        var _token = "<?php echo e(csrf_token()); ?>";
    </script>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>

<div class="header container-fluid zero-padding">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 margin-10">
                <div class="col-xs-10 text-left zero-padding">
                    <img src="/frontend/images/logob&k.png" alt="logo">
                    <div class="links">
                        <a href="<?php echo e(route('home.index')); ?>" class="link1 <?php echo e(\Request::route()->getName() == 'home.index' ? 'main-header-active': ''); ?>"><?php echo e(getTranslation('emergency_app')); ?></a>
                        <a href="<?php echo e(route('claim.create')); ?>" class="link2 <?php echo e(\Request::route()->getName() == 'claim.create' ? 'main-header-active': ''); ?>"><?php echo e(getTranslation('claim_form')); ?></a>
                        <?php
                            $roles = \Auth::user()->roles;
                            $rolesArray = [];
                            if(count($roles) > 0) {
                                $rolesArray = $roles->pluck('name')->toArray();
                            }
                        ?>
                        <?php if(in_array('ADMIN', $rolesArray)): ?>
                            <a href="<?php echo e(route('dashboard.index')); ?>" class="link2 <?php echo e(\Request::route()->getName() == 'dashboard.index' ? 'main-header-active': ''); ?>"><?php echo e(getTranslation('admin_panel')); ?></a>
                        <?php elseif(in_array('AGENT', $rolesArray)): ?>
                            <a href="<?php echo e(route('claim.index')); ?>" class="link2 <?php echo e(\Request::route()->getName() == 'claim.index' ? 'main-header-active': ''); ?>"><?php echo e(getTranslation('my_claims')); ?></a>
                        <?php endif; ?>

                        <?php if(isset(\Auth::user()->customer) && !is_null(\Auth::user()->customer->shared_link)): ?>
                            <a href="<?php echo e(\Auth::user()->customer->shared_link); ?>" class="link2" target="_blank"><?php echo e(getTranslation('shared_link')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-xs-2 zero-padding text-right padding-15">
                    <div class="right-section">
                        <img src="/frontend/images/logout.png" alt="img" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" style="cursor: pointer;">
                        <h3 onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">logout</h3>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                </div>
            </div>
            <div class="col-xs-10 text-left zero-padding">
                <?php if(session('status')): ?>
                    <p class="alert alert-success"><?php echo getTranslation('contact_bnk_password_reset_message'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<div id="modal-delete" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Are you sure to delete?</h4>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="delete-confirm"><?php echo e(getTranslation('delete')); ?></button>
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(getTranslation('close')); ?></button>
            </div>
        </div>

    </div>
</div>

<div class="footer container-fluid zero-padding text-center">
    <div class="container">
        <div class="row">
            <span class="footer-text">© 2013-<?php echo date('Y', time()); ?> B&K, Inc. All rights reserved.</span>
            <img src="/frontend/images/white-logo.png" alt="logo">
        </div>
    </div>
</div>


<script type="text/javascript" src="<?php echo e(asset('frontend/script/jquery-3.3.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend/script/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('frontend/script/custom.js')); ?>"></script>
<script src="<?php echo e(asset('/common/js/common.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>
</html>

