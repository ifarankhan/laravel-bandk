
<h1><?php echo e($category->title); ?></h1>

<?php if(count($content) > 0): ?>
    <div class="section category-front">
        <h2><?php echo e($content->title); ?></h2>
        <p>
            <?php echo $content->description; ?>

        </p>
    </div>
<?php endif; ?>