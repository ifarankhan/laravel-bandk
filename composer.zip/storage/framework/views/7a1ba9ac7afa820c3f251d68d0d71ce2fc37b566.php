<?php $__env->startSection('content'); ?>
    <div class="outer">
        <div class="inner">
            <div class="login-section">
                <div class="login-container">
                    <img src="/frontend/images/logob&k.png" alt="img">
                    <ul>
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <li class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

                                <input type="text" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </li>
                            <li class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">

                                <input type="password" placeholder="Password" name="password">
                            </li>
                            <li>
                                <button type="submit">Login</button>
                            </li>
                            <li>
                                <input type="checkbox" class="remember-me" value="Remember">
                                <span class="remember">Remember me</span>
                                <a href="<?php echo e(route('password.request')); ?>" class="forgot">Forgotten account?</a>
                            </li>
                        </form>
                    </ul>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-front-login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>