<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(getTranslation('dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('department.index')); ?>"><?php echo e(getTranslation('department')); ?></a></li>
    </ul>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Edit Department </h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <br />
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(route('department.store')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($department->id); ?>">
                        <input type="hidden" value="<?php echo e($department->team_id); ?>" id="hidden_teams_id">
                        <input type="hidden" value="<?php echo e($department->company_id); ?>" id="hidden_company_id">
                        <div class="form-group">
                            <label class="control-label col-md-1 col-sm-1 col-xs-12" for="name"><?php echo e(getTranslation('department')); ?> <span class="required">*</span>
                            </label>
                            <div class="col-md-11 col-sm-11 col-xs-12">
                                <input type="text" id="name" required="required" class="form-control col-md-7 col-xs-12" name="name" value="<?php echo e($department->name); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-1 col-sm-1 col-xs-12" for="policy_number"><?php echo e(getTranslation('customer_policy_number')); ?>

                            </label>
                            <div class="col-md-11 col-sm-11 col-xs-12">
                                <input type="text" id="policy_number" class="form-control col-md-7 col-xs-12" name="policy_number" value="<?php echo e($department->policy_number); ?>">
                                <?php if($errors->has('policy_number')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('policy_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-1 col-sm-1 col-xs-12" for="customer_id"><?php echo e(getTranslation('customer')); ?><span class="required">*</span>
                            </label>
                            <div class="col-md-11 col-sm-11 col-xs-12">
                                <select class="form-control col-md-7 col-xs-12" name="customer_id" id="customer_id" data-url="/customer/teams/">
                                    <option value=""><?php echo e(getTranslation('select_customer')); ?></option>
                                    <?php if(count($customers) > 0): ?>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>" <?php echo e(($department->customer_id == $customer->id) ? "selected='selected'" : ''); ?>><?php echo e($customer->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php if($errors->has('customer_id')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('customer_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-1 col-sm-1 col-xs-12" for="team_id"><?php echo e(getTranslation('teams')); ?><span class="required">*</span>
                            </label>
                            <div class="col-md-11 col-sm-11 col-xs-12">
                                <select class="form-control col-md-7 col-xs-12" name="team_id" id="team_id" disabled="disabled">
                                </select>
                                <?php if($errors->has('team_id')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('team_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-1 col-sm-1 col-xs-12" for="company_id"><?php echo e(getTranslation('company')); ?><span class="required">*</span>
                            </label>
                            <div class="col-md-11 col-sm-11 col-xs-12">
                                <select class="form-control col-md-7 col-xs-12" name="company_id" id="company_id" disabled="disabled">

                                </select>
                                <?php if($errors->has('company_id')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('company_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-1 col-sm-1 col-xs-12">&nbsp
                            </label>
                            <div class="col-md-11 col-sm-11 col-xs-12">
                                <div class="col-md-10" >
                                    <table >
                                        <thead>
                                        <tr>
                                            <td style="width:150px;" class="col-md-3 col-xs-12" >Adresse</td>
                                            <td style="width:150px;" class="col-md-2 col-xs-12" >Post nr.</td>
                                            <td style="width:150px;" class="col-md-2 col-xs-12" >By</td>
                                            <td style="width:150px;" class="col-md-2 col-xs-12" >Bygge år</td>
                                            <td style="width:150px;" class="col-md-3 col-xs-12" >Etageareal</td>
                                        </tr>
                                        </thead>

                                        <tbody class="addresses" id="address_div">
                                        <?php if(count($department->addresses) > 0): ?>
                                            <?php $__currentLoopData = $department->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr style="margin-bottom: 35px;" >
                                                    <td><input type="text"  style="width: 150px;" class="form-control col-md-3 col-xs-12" name="addresses[<?php echo e($address->id); ?>][address]" value="<?php echo e($address->address); ?>"></td>
                                                    <td><input type="text"  style="width: 150px;" class="form-control col-md-2 col-xs-12" name="addresses[<?php echo e($address->id); ?>][zip_code]" value="<?php echo e($address->zip_code); ?>"></td>
                                                    <td><input type="text"  style="width: 150px;" class="form-control col-md-2 col-xs-12" name="addresses[<?php echo e($address->id); ?>][city]" value="<?php echo e($address->city); ?>"></td>
                                                    <td><input type="text"  style="width: 150px;" class="form-control col-md-2 col-xs-12" name="addresses[<?php echo e($address->id); ?>][build_year]" value="<?php echo e($address->build_year); ?>"></td>
                                                    <td><input type="text"  style="width: 150px;" class="form-control col-md-3 col-xs-12" name="addresses[<?php echo e($address->id); ?>][m2]" value="<?php echo e($address->m2); ?>"></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>


                                    </table>

                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-danger pull-right" type="button" id="add_address">Add Address</button>
                                </div>

                            </div>
                        </div>

                        <br />
                        <br />
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <a class="btn btn-danger" href="<?php echo e(route('department.index')); ?>">Back</a>
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/vendors/select2/dist/css/select2.min.css')); ?> " rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script>
        jQuery(document).ready(function(){
           jQuery("#roles").on('change', function(){
                var value = jQuery(this).val();

                if(jQuery.inArray("2", value) !== -1) {
                    jQuery("#department_id_div").show();
                    jQuery("#department_id").prop( "disabled", false );
                } else {
                    jQuery("#department_id_div").hide();
                    jQuery("#department_id").prop( "disabled", true );
                }
           });
        });
        $('.select2').select2();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>