<?php $__env->startSection('css'); ?>
    <style>
        .h3, h3 {
            font-size: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('dashboard.index')); ?>" method="GET">
        <div class="row">
            <div class="form-group form-group-sm col-md-12 col-lg-12">
                <div class="row">
                    <div class="col-md-4 col-lg-4">
                        <label for="customer_id">
                            <?php echo e(getTranslation('customer')); ?>

                        </label>
                        <select id="customer_id" class="form-control" name="search[customer_id]" tabindex="-1" aria-hidden="true">
                            <option value=""><?php echo e(getTranslation('select_customer')); ?></option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($aCustomer->id); ?>" <?php echo e((session('customer_id') && session('customer_id') == $aCustomer->id) ? 'selected="selected"' : ''); ?>><?php echo e($aCustomer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <div class="col-md-4 col-lg-4">
                        <div class="form-group form-group-sm ">
                            <label for="customer_id">
                                &nbsp;
                            </label>
                            <div class="">
                                <button class="btn btn-danger" type="submit"><?php echo e(getTranslation('submit')); ?></button>
                                <a class="btn btn-success" href="<?php echo e(route('reset.url')); ?>"><?php echo e(getTranslation('reset')); ?></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </form>
    <?php if($search && isset($search['customer_id'])): ?>
        <div class="row">
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo e(route('department.index')); ?>?search[customer_id]=<?php echo e($search['customer_id']); ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa fa-users"></i>
                    </div>
                    <div class="count"><?php echo e(getTranslation('department')); ?></div>
                    <h3><?php echo e(getTranslation('department')); ?></h3>
                </div>
            </a>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo e(route('claim.index')); ?>?search[customer_id]=<?php echo e($search['customer_id']); ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa fa-users"></i>
                    </div>
                    <div class="count"><?php echo e(getTranslation('claims')); ?></div>
                    <h3>Skadehåndtering</h3>
                </div>
            </a>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo e(route('category.index')); ?>?search[customer_id]=<?php echo e($search['customer_id']); ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa fa-briefcase"></i>
                    </div>
                    <div class="count"><?php echo e(getTranslation('categories')); ?></div>
                    <h3>Beredskabsplan</h3>
                </div>
            </a>
        </div>
            <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <a href="<?php echo e(route('content.index')); ?>?search[customer_id]=<?php echo e($search['customer_id']); ?>">
                    <div class="tile-stats">
                        <div class="icon"><i class="fa fa-briefcase"></i>
                        </div>
                        <div class="count"><?php echo e(getTranslation('content')); ?></div>
                        <h3>Beredskabsplan</h3>
                    </div>
                </a>
            </div>


    </div>
    <?php endif; ?>
    <div class="row">
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo e(($search && isset($search['customer_id'])) ? route('users.index').'?search[customer_id]='.$search['customer_id'] :  route('users.index')); ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa fa-users"></i>
                    </div>
                    <div class="count"><?php echo e($userCount); ?></div>

                    <h3><?php echo e(getTranslation('total_users')); ?></h3>
                </div>
            </a>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo e(($search && isset($search['customer_id'])) ? route('customer.index').'?search[customer_id]='.$search['customer_id'] : route('customer.index')); ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa fa-users"></i>
                    </div>
                    <div class="count"><?php echo e($customersCount); ?></div>

                    <h3><?php echo e(getTranslation('total_customer')); ?></h3>
                </div>
            </a>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo e(($search && isset($search['customer_id'])) ? route('claim.index').'?search[customer_id]='.$search['customer_id'] :  route('claim.index')); ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa fa-briefcase"></i>
                    </div>
                    <div class="count"><?php echo e($claimCount); ?></div>

                    <h3><?php echo e(getTranslation('total_claims')); ?></h3>
                </div>
            </a>
        </div>
        <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <a href="<?php echo e(($search && isset($search['customer_id'])) ? route('claim.index').'?search[customer_id]='.$search['customer_id'] : route('claim.index')); ?>&search[date]=<?php echo e(date('Y-m-d')); ?>">
                <div class="tile-stats">
                    <div class="icon"><i class="fa fa-briefcase"></i>
                    </div>
                    <div class="count"><?php echo e($todayCount); ?></div>

                    <h3><?php echo e(getTranslation('today_claims')); ?></h3>
                </div>
            </a>
        </div>
    </div>

    <div class="row">
        <div class="x_panel">
            <div class="x_title">
                <h2><?php echo e(getTranslation('today_claims')); ?></h2>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">

                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th><?php echo e(getTranslation('customer_name')); ?></th>
                        <th><?php echo e(getTranslation('claim_type')); ?></th>
                        <th><?php echo e(getTranslation('estimate')); ?></th>
                        <th><?php echo e(getTranslation('date')); ?></th>
                        <th><?php echo e(getTranslation('department')); ?></th>
                        <th><?php echo e(getTranslation('address_1')); ?></th>
                        <th><?php echo e(getTranslation('address_2')); ?></th>
                        <th><?php echo e(getTranslation('actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $todayClaims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(($claim->customer && $claim->customer->name)  ? $claim->customer->name : ''); ?></td>
                                <td><?php echo e(($claim->type) ? $claim->type->name : ''); ?></td>
                                <td><?php echo e($claim->estimate); ?></td>
                                <td><?php echo e($claim->date); ?></td>
                                <td><?php echo e(($claim->department) ? $claim->department->name : ''); ?></td>
                                <td><?php echo e(($claim->address1)  ? $claim->address1->address : ''); ?></td>
                                <td><?php echo e(($claim->address_2)  ? $claim->address_2 : ''); ?></td>
                                <td>
                                    <a href="<?php echo e(route('claim.details', ['id'=> $claim->id])); ?>" class="btn btn-success"><?php echo e(getTranslation('details')); ?></a>
                                    <a href="<?php echo e(route('claim.edit', ['id'=> $claim->id])); ?>" class="btn btn-info"><?php echo e(getTranslation('edit')); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>