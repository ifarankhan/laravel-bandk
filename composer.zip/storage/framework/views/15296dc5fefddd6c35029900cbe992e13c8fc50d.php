<?php $__env->startSection('content'); ?>
    <div class="col-md-2 column">
        <div class="sideNav" style="width: 100%;height: 100%;">
            <button>
                <span></span>
            </button>
            <ul>
                <?php
                $html = '';
                ?>
                <?php echo getLeftMenu($categories, $html); ?>

            </ul>
        </div>
    </div>
    <div class="col-md-10 col-sm-12 detail column" id="content-details">

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .detail h1 {
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>