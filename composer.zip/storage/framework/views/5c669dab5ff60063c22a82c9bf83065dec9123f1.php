<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="form-section">
                <h1>Claim Form</h1>

                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <form action="<?php echo e(route('claim.create.post')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="status" value="OPEN">
                    <input type="hidden" name="from_web" value="from_web">
                    <?php
                        $roles = \Auth::user()->roles;

                        if(count($roles) > 0) {
                            $roles = $roles->pluck('name')->toArray();
                        }
                    ?>

                    <?php if(in_array('ADMIN', $roles)): ?>
                        <div class="form-group ">
                        <label for="heading"><?php echo e(getTranslation('customer')); ?>

                            <i class="fa fa-spin fa-spinner" style="display: none;" id="customer_loader"></i>
                        </label>
                        <select class="form-control" name="customer_id" id="customer_id" data-url="/customer/departments/">
                            <option value=""><?php echo e(getTranslation('select_customer_id')); ?></option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>" <?php echo e(old('customer_id') == $customer->id ? 'selected="selected"' : ''); ?>><?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" id="customer_<?php echo e($customer->id); ?>" value="<?php echo e(json_encode($customer)); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($errors->has('customer_id')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('customer_id')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <input type="hidden" name="customer_id" id="customer_id" data-url="/customer/departments/" value="<?php echo e(\Auth::user()->customer_id); ?>">
                    <?php endif; ?>

                    <div class="form-group ">
                        <label for="department"><?php echo e(getTranslation('department')); ?>

                            <i class="fa fa-spin fa-spinner" style="display: none;" id="department_loader"></i>
                        </label>
                        <input type="hidden" value="<?php echo e(old('department_id')); ?>" id="hidden_department_1">
                        <select class="form-control" name="department_id" id="department_id" data-url="/department/address/">
                            <option value=""><?php echo e(getTranslation('select_department')); ?></option>
                        </select>
                        <?php if($errors->has('department_id')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('department_id')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group ">
                        <label for="address"><?php echo e(getTranslation('address_1')); ?></label>
                        <input type="hidden" value="<?php echo e(old('address_1')); ?>" id="hidden_address_1">
                        <select class="form-control" name="address_1" id="address_1">
                        </select>
                        <?php if($errors->has('address_1')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('address_1')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group ">
                        <label for="Address"><?php echo e(getTranslation('address_2')); ?></label>
                        <input type="text" class="form-control" id="address" name="address_2" value="<?php echo e(old('address_2')); ?>">
                        <?php if($errors->has('address_2')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('address_2')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group ">
                        <label for="heading"><?php echo e(getTranslation('claim_type')); ?></label>
                        <select class="form-control" name="claim_type_id">
                            <option value=""><?php echo e(getTranslation('select_claim_type')); ?></option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>" <?php echo e(old('claim_type_id') == $type->id ? 'selected="selected"' : ''); ?>><?php echo e($type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('claim_type_id')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('claim_type_id')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group ">
                        <label for="date"><?php echo e(getTranslation('date')); ?></label>
                        <input type="text" class="form-control" id="date" name="date" value="<?php echo e(old('date')); ?>" placeholder="dd/mm/yyyy" autocomplete="off">
                        <?php if($errors->has('date')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('date')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label ><?php echo e(getTranslation('is_damage_inspected')); ?></label>
                        <div class="radio">
                            <label for="optionsRadios1">
                                <input type="radio"  value="1" id="optionsRadios1" name="is_damage_inspected"> Yes
                            </label>
                            <label for="optionsRadios2">
                                <input type="radio" checked="" value="0" id="optionsRadios2" name="is_damage_inspected"> No
                            </label>
                        </div>
                    </div>
                    <div class="form-group ">
                        <label for="estimate"><?php echo e(getTranslation('estimate')); ?></label>
                        <input type="text" class="form-control" id="estimate" name="estimate" value="<?php echo e(old('estimate')); ?>" maxlength="10">
                        <?php if($errors->has('estimate')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('estimate')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group ">
                        <label for="Description" class="display-block"><?php echo e(getTranslation('description')); ?></label>
                        <textarea rows="5" cols="64" name="description"><?php echo e(old('description')); ?></textarea>
                        <?php if($errors->has('description')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                        <?php endif; ?>
                    </div>

                    

                    <div class="form-group">
                        <label for="fileUpload"><?php echo e(getTranslation('attach_photo')); ?></label>
                        <input type="file" id="fileUpload" multiple="multiple" name="images[]">
                        <?php if($errors->has('images')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('images')); ?></strong>
                                </span>
                        <?php endif; ?>
                        <div id="image-holder">
                        </div>
                    </div>


                    <button class="send">Send</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="<?php echo e(asset('/admin/vendors/select2/dist/css/select2.min.css')); ?> " rel="stylesheet">
    <style>
        #image-holder img {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 5px;
            width: 150px;
            height: 100px;
        }

        #image-holder img:hover {
            box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
        }

        .help-block{
            color: #a94442;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
        $('.select2').select2();
        $( function() {
            $( "#date" ).datepicker({ dateFormat: 'dd/mm/yy',maxDate: '0' });
        } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>