<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(getTranslation('dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('users.index')); ?>"><?php echo e(getTranslation('users')); ?></a></li>
    </ul>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Users Lists</h2>
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-danger pull-right">Opret</a>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="flash-message">
                        <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has('alert-' . $msg)): ?>
                                <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <form action="<?php echo e(route('users.index')); ?>" method="GET">
                        <div class="row">
                            <div class="form-group form-group-sm col-md-12 col-lg-12">
                                <div class="row">
                                    <div class="col-md-4 col-lg-4">
                                        <label for="customer_id">
                                            <?php echo e(getTranslation('customer')); ?>

                                        </label>
                                        <select id="customer_id" class="form-control" name="search[customer_id]" tabindex="-1" aria-hidden="true">
                                            <option value=""><?php echo e(getTranslation('select_customer')); ?></option>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($aCustomer->id); ?>" <?php echo e((session('customer_id') && session('customer_id') == $aCustomer->id) ? 'selected="selected"' : ''); ?>><?php echo e($aCustomer->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="col-md-4 col-lg-4">
                                        <div class="form-group form-group-sm ">
                                            <label for="customer_id">
                                                &nbsp;
                                            </label>
                                            <div class="">
                                                <button class="btn btn-danger" type="submit"><?php echo e(getTranslation('submit')); ?></button>
                                                <a class="btn btn-success" href="<?php echo e(route('reset.url')); ?>"><?php echo e(getTranslation('reset')); ?></a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </form>
                    <table id="datatable1" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Department</th>
                            <th>Roles</th>
                            <th>Modules</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="user_<?php echo e($user->id); ?>">
                                <td><?php echo e(ucfirst($user->name )); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e(($user->department) ? $user->department->name : ''); ?></td>
                                <td><?php echo e(($user->roles) ? implode(',', $user->roles->pluck('name')->toArray()) : ''); ?></td>
                                <td><?php echo e(($user->modules) ? implode(',', $user->modules->pluck('text')->toArray()) : ''); ?></td>
                                <td>
                                    <a href="<?php echo e(route('users.edit', ['id'=> $user->id])); ?>" class="btn btn-success">Edit</a>
                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline" data-toggle="tooltip" data-placement="top" title="<?php echo e(getTranslation('disable_enable_user')); ?>">
                                        <?php echo e(getTranslation('disable_enable_user')); ?>

                                        <input type="checkbox" class="checkboxes enable-disable" data-url="<?php echo e(route('users.status', ['id' => $user->id])); ?>"
                                               data-csrf="<?php echo e(csrf_token()); ?>" data-id="<?php echo e($user->id); ?>" <?php if($user->status): ?> checked="checked" <?php endif; ?> />
                                        <i class="fa fa-spin fa-spinner" id="loader_<?php echo e($user->id); ?>" style="display: none;"></i>
                                        <span></span>
                                    </label>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?> " rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.print.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-scroller/js/dataTables.scroller.min.js')); ?> "></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>