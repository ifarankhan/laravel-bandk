<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(getTranslation('dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('department.index')); ?>"><?php echo e(getTranslation('department')); ?></a></li>
    </ul>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Departments Lists</h2>
                    <a href="<?php echo e(route('department.create')); ?>" class="btn btn-danger pull-right">Opret</a>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="flash-message">
                        <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has('alert-' . $msg)): ?>
                                <p class="alert alert-<?php echo e($msg); ?>"><?php echo Session::get('alert-' . $msg); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <form action="<?php echo e(route('department.index')); ?>" method="GET">
                        <div class="row">
                            <div class="form-group form-group-sm col-md-12 col-lg-12">
                                <div class="row">
                                    <div class="col-md-3 col-lg-3">
                                        <label for="customer_id">
                                            <?php echo e(getTranslation('customer')); ?>

                                        </label>
                                        <select id="customer_id" class="form-control" name="search[customer_id]" tabindex="-1" aria-hidden="true" name="customer_id" data-url="/customer/companies/">
                                            <option value=""><?php echo e(getTranslation('select_customer')); ?></option>
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($aCustomer->id); ?>" <?php echo e(($search && isset($search['customer_id']) && $search['customer_id'] == $aCustomer->id) ? 'selected="selected"' : ''); ?>><?php echo e($aCustomer->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-3">
                                        <label for="department"><?php echo e(getTranslation('company')); ?>

                                            <i class="fa fa-spin fa-spinner" style="display: none;" id="company_loader"></i>
                                        </label>
                                        <input type="hidden" value="<?php if(isset( $search['company_id'])): ?>company_id <?php echo e($search['company_id']); ?> <?php endif; ?>" id="hidden_company_1">
                                        <select class="form-control" name="search[company_id]" id="_id" data-url="/company/departments/">
                                            <option value=""><?php echo e(getTranslation('select_company')); ?></option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-3 ">
                                        <label for="department"><?php echo e(getTranslation('department')); ?>

                                            <i class="fa fa-spin fa-spinner" style="display: none;" id="department_loader"></i>
                                        </label>
                                        <input type="hidden" value="<?php echo e(isset($search['department_id']) ? $search['department_id'] : ''); ?>" id="hidden_department_1">
                                        <select class="form-control" name="search[department_id]" id="department_id" data-url="/department/address/">
                                            <option value=""><?php echo e(getTranslation('select_department')); ?></option>
                                        </select>
                                    </div>
                                    <div class="col-md-3 col-lg-3">
                                        <div class="form-group form-group-sm ">
                                            <label for="customer_id">
                                                &nbsp;
                                            </label>
                                            <div class="">
                                                <button class="btn btn-danger" type="submit"><?php echo e(getTranslation('submit')); ?></button>
                                                <a class="btn btn-success" href="<?php echo e(route('reset.url')); ?>"><?php echo e(getTranslation('reset')); ?></a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </form>
                    <?php
                    $departmentsArray = [];
                    if(count($departments) > 0) {
                        foreach ($departments as $department) {
                            $departmentsArray[$department->id][] = $department;
                        }
                    }
                    ?>
                    <table id="datatable1" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th><?php echo e(getTranslation('department')); ?></th>
                            <th>Customer</th>
                            <td style="width:150px;" class="col-md-3 col-xs-12" >Address</td>
                            <td style="width:150px;" class="col-md-3 col-xs-12" >Post nr.</td>
                            <td style="width:150px;" class="col-md-3 col-xs-12" >By</td>
                            <td style="width:150px;" class="col-md-3 col-xs-12" >Byggeår</td>
                            <td style="width:150px;" class="col-md-3 col-xs-12" >Etageareal</td>
                            <th><?php echo e(getTranslation('action')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        
                            <?php $__currentLoopData = $departmentsArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departmentsA): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $departmentsA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $department->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="content_<?php echo e($address->id); ?>"  style="<?php echo e(($key1 == 0 && $key == 0) ? '' : 'display:none'); ?>" class="<?php echo e(($key1 == 0 && $key == 0) ? '' : 'toggle-class-'.$department->id); ?>">
                                            <td data-order="<?php echo e(intval($department->name)); ?>">
                                                <?php echo ($key1 == 0 && $key == 0) ? $department->name : ''; ?>

                                                <?php echo ($key1 == 0 && $key == 0 && count($department->addresses) > 1) ? '<br /><br /><i style="cursor:pointer;color: #0275d8;" class="show_more down icon-my pull-right" data-what-to-do="down" data-department-id="'.$department->id.'">': ''; ?>

                                            </td>
                                            <td style="width: 150px;" class="col-md-3 col-xs-12" ><?php echo e(($department->customer) ? $department->customer->name : ''); ?></td>
                                            <td style="width: 150px;" class="col-md-3 col-xs-12" ><?php echo e($address->address); ?></td>
                                            <td style="width: 150px;" class="col-md-3 col-xs-12" ><?php echo e($address->zip_code); ?></td>
                                            <td style="width: 150px;" class="col-md-3 col-xs-12" ><?php echo e($address->city); ?></td>
                                            <td style="width: 150px;" class="col-md-3 col-xs-12" ><?php echo e($address->build_year); ?></td>
                                            <td style="width: 150px;" class="col-md-3 col-xs-12" ><?php echo e($address->m2); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('department.edit', ['id'=> $department->id])); ?>" class="btn btn-success">Redigere</a>
                                                <button data-id="<?php echo e($department->id); ?>" data-url="<?php echo e(route('department.delete', ['id'=> $department->id])); ?>" class="btn btn-danger delete" data-toggle="modal" data-target="#modal-delete" data-csrf="<?php echo e(csrf_token()); ?>"><?php echo getTranslation('delete'); ?></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?> " rel="stylesheet">
    <style>
        .show {
            display: block;
        }

        .hide {
            display: none;
        }
        .up {
            transform: rotate(-135deg);
            -webkit-transform: rotate(-135deg);
        }

        .down {
            transform: rotate(45deg);
            -webkit-transform: rotate(45deg);
        }
        .icon-my {
            border: solid black;
            border-width: 0 3px 3px 0;
            display: inline-block;
            padding: 3px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.print.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-scroller/js/dataTables.scroller.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script>
        jQuery(document).ready(function () {
            $('.show_more').on('click', function () {
                var whatToDO = $(this).attr('data-what-to-do');
                var departmentId = $(this).attr('data-department-id');

                if(whatToDO == 'down') {
                    $(this).attr('data-what-to-do', 'up');
                    $(".toggle-class-"+departmentId).show();
                    $(this).removeClass('down').addClass('up');
                    //$(this).html('Hide');
                } else {
                    $(this).attr('data-what-to-do', 'down');
                    $(".toggle-class-"+departmentId).hide();
                    $(this).removeClass('up').addClass('down');
                }


            });
            $('#datatable1').dataTable(
                {
                    searching: false,
                    paging: false
                }
            );
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>