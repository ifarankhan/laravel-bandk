<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(getTranslation('dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('claim.index')); ?>"><?php echo e(getTranslation('claims')); ?></a></li>
    </ul>
    <div class="flash-message">
        <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Session::has('alert-' . $msg)): ?>
                <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <form action="<?php echo e(route('claim.detail.form')); ?>" method="POST">
                <?php if(isAdmin(\Auth::user())): ?>
                    <div class="row">
                    <div class="col-md-4">
                        <div class="ribbon ribbon-border-hor ribbon-clip ribbon-color-danger uppercase">
                            <div class="ribbon-sub ribbon-clip"><?php echo e(getTranslation('claim_details')); ?></div>
                        </div>
                    </div>
                    <div class="col-md-2"></div>
                    <div class="col-md-6">
                        <div class="row">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($claim->id); ?>">
                            <div class="form-group col-md-6">
                                <select class="form-control" name="status">
                                    <option value=""><?php echo e(getTranslation('select_status')); ?></option>
                                    <option value="CLOSED" <?php echo e($claim->status == 'CLOSED' ? 'selected="selected"' : ''); ?>><?php echo e(getTranslation('closed')); ?></option>
                                    <option value="OPEN" <?php echo e($claim->status == 'OPEN' ? 'selected="selected"' : ''); ?>><?php echo e(getTranslation('open')); ?></option>
                                </select>
                                <?php if($errors->has('status')): ?>
                                    <span class="help-block">
                                                <strong><?php echo e($errors->first('status')); ?></strong>
                                            </span>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <div class="mt-element-ribbon bg-grey-steel">
                <div class="row ribbon-content">

                    <div class="row">
                        <div class="col-md-2"><strong><?php echo e(getTranslation('customer_name')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->customer) ?  $claim->customer->name : ''); ?></div>
                    </div>
                    <hr style="border-top: 1px solid gray;"/>

                    <div class="row">
                        <div class="col-md-2"><strong><?php echo e(getTranslation('claim_id')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e($claim->id); ?></div>
                        <div class="col-md-2"><strong><?php echo e(getTranslation('department')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->department) ? $claim->department->name : ''); ?></div>
                        <div class="col-md-2"><strong><?php echo e(getTranslation('date')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e($claim->date); ?></div>
                    </div>
                    <hr style="border-top: 1px solid gray;"/>
                    <div class="row">
                        <div class="col-md-4">&nbsp;</div>
                        <div class="col-md-2"><strong><?php echo e(getTranslation('address_1')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->address1)  ? $claim->address1->address : ''); ?></div>
                        <div class="col-md-2"><strong><?php echo e(getTranslation('claim_type')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->type) ? $claim->type->name : ''); ?></div>
                    </div>
                    <hr style="border-top: 1px solid gray;"/>
                    <div class="row">
                        <div class="col-md-4"><strong>Selskab skade nummer:</strong></div>
                        <div class="col-md-2"><strong><?php echo e(getTranslation('address_2')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->address_2)  ? $claim->address_2 : ''); ?></div>
                        <div class="col-md-2"><strong><?php echo e(getTranslation('estimate')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e($claim->estimate); ?></div>
                    </div>
                    <hr style="border-top: 1px solid gray;"/>

                    <div class="row">
                        <div class="col-md-4"><input type="hidden" name="id" value="<?php echo e($claim->id); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div style="margin-left: -2px;">
                                <input type="text" id="selsskab_skade_nummer" class="form-control" name="selsskab_skade_nummer" value="<?php echo e($claim->selsskab_skade_nummer); ?>" placeholder="Selskab skade nummer">
                            </div>
                        </div>
                        <div class="col-md-2"><strong><?php echo e(getTranslation('customer_zip_code')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->address1) ?  $claim->address1->zip_code : ''); ?></div>
                        <div class="col-md-4">&nbsp;</div>
                    </div>
                    <hr style="border-top: 1px solid gray;"/>

                    <div class="row">
                        <div class="col-md-4">&nbsp;</div>
                        <div class="col-md-2 "><strong><?php echo e(getTranslation('customer_city')); ?>:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->customer) ? $claim->customer->city : ''); ?></div>
                        <div class="col-md-2"><strong>Anmelder:</strong></div>
                        <div class="col-md-2 bg-white"><?php echo e(($claim->user) ? $claim->user->name. ' ('.$claim->user->email.')' : ''); ?></div>
                    </div>
                    <hr style="border-top: 1px solid gray;"/>

                    <div class="row">
                        <div class="col-md-12"><strong><?php echo e(getTranslation('is_damage_inspected')); ?></strong></div>
                    </div>
                    <hr style="border-top: 1px solid gray;"/>
                    <div class="row">
                        <div class="col-md-4">
                            <input type="hidden" name="id" value="<?php echo e($claim->id); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="radio">
                                <label>
                                    <input type="radio" <?php echo e(($claim->is_damage_inspected) ? 'checked=""' : ''); ?> value="1" id="optionsRadios1" name="is_damage_inspected"> Yes
                                </label>
                                <label>
                                    <input type="radio" <?php echo e((!$claim->is_damage_inspected) ? 'checked=""' : ''); ?> value="0" id="optionsRadios2" name="is_damage_inspected"> No
                                </label>
                            </div>
                        </div>
                    </div>
                    <?php if(isAdmin(\Auth::user())): ?>
                        <div class="row">
                            <div class="col-md-8"></div>
                            <div class="col-md-4">
                                <button class=" btn btn-<?php echo e(getClaimColor($claim)); ?> " type="submit"><?php echo e(getTranslation('submit')); ?></button>
                            </div>
                        </div>
                    <?php endif; ?>


                    <div class="row">
                        <div class="col-md-12">
                            <strong><?php echo e(getTranslation('description')); ?>:</strong> &nbsp;<?php echo e($claim->description); ?>

                        </div>
                    </div>
                </div>
            </div>

            </form>
        </div>
    </div>
    <?php if(count($claim->images) > 0): ?>

        <div class="row">

            <div class="imageGallery1 col-md-12">
                <?php $__currentLoopData = $claim->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3" >
                        <a href="<?php echo e($image->image); ?>" >
                            <img class="img-responsive <?php echo e(needRotate($image->image_path) ? 'rotate' : ''); ?>" src="<?php echo e($image->image); ?>" style="width: 250px; height: 250px;"/>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
    <br />
    <br />
    <div class="row">

        <h4><?php echo e(getTranslation('conversation')); ?></h4>

        <!-- end of user messages -->
        <div class="col-md-8">
            <ul class="messages">

                <?php if(count($claim->conversations) > 0): ?>
                    <?php $__currentLoopData = $claim->conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li id="conversation_<?php echo e($conversation->id); ?>">
                           <div class="message_wrapper">
                               <div class="message_date">
                                   <div class="col-md-8">
                                       <h3 class="date text-info"><?php echo e(date('d', strtotime($conversation->created_at))); ?></h3>
                                       <p class="month"><?php echo e(date('M', strtotime($conversation->created_at))); ?></p>
                                   </div>
                                   <?php if(isAdmin(\Auth::user())): ?>
                                       <div class="col-md-4">
                                           <p style="margin-top: 12px;">
                                           <button class="btn btn-danger btn-xs delete-conversation" title="Delete" data-id="<?php echo e($conversation->id); ?>" data-url="<?php echo e(route('claimconversation.delete', ['id'=> $conversation->id])); ?>" data-csrf="<?php echo e(csrf_token()); ?>">
                                               <i class="fa fa-trash"></i>
                                           </button>
                                           </p>
                                       </div>
                                   <?php endif; ?>

                               </div>

                               <span class="caption">
                                  <blockquote class="message"><?php echo e($conversation->conversation); ?></blockquote>
                                </span>
                                <br />

                                <?php if(count($conversation->files) > 0): ?>
                                    <?php $__currentLoopData = $conversation->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row" id="conversation_file_<?php echo e($file->id); ?>">
                                            <div class="col-md-8" >
                                                <a href="<?php echo e(asset('/files/'.$file->file_name)); ?>" download="<?php echo e($file->file_name); ?>"><i class="fa fa-paperclip"></i> <?php echo e($file->file_name); ?> </a><br>
                                            </div>







                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php endif; ?>
            </ul>
        </div>
        <?php if(isAdmin(\Auth::user())): ?>
            <div class="col-md-4">
            <form id="demoForm2" data-parsley-validate class="form-horizontal form-label-left dropzone" action="<?php echo e(route('claim.conversation.store')); ?>" method="POST" enctype='multipart/form-data'>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="claim_id" value="<?php echo e($claim->id); ?>">
                <div class="form-group">
                    <label class="control-label col-md-12 col-sm-12 col-xs-12" style="text-align: left;" for="description"><?php echo e(getTranslation('add_conversation')); ?> <span class="required">*</span>
                    </label>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <textarea id="conversation" col="10" row="15" class="form-control col-md-7 col-xs-12" name="conversation"><?php echo e(old('conversation')); ?></textarea>
                        <?php if($errors->has('conversation')): ?>
                            <span class="help-block" style="color: red;">
                                <strong><?php echo e($errors->first('conversation')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <br />
                <br />
                <div class="form-group">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <span class="col-md-8">
                            
                            <?php if($errors->has('all_files.0')): ?>
                                <span class="help-block" style="color: red;">
                                <strong>File must be of type pdf, doc, docx.</strong>
                            </span>
                            <?php endif; ?>
                            <div id="fileList"></div>
                        </span>
                        <span class="col-md-4">
                        </span>

                    </div>
                </div>

            </form>
            <button type="submit" id="btn_submit" class="btn btn-success pull-left btn-xs">Submit</button>

        </div>
        <?php endif; ?>

    </div>

    <?php echo e(isUpdated($claim)); ?>


    <div id="modal-delete-file" class="modal fade" role="dialog" style="z-index: 9999">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Are you sure to delete?</h4>
                </div>
                <div class="modal-body">
                    Are you sure to delete?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" id="delete-confirm">Delete</button>
                    <button type="button" class="btn btn-default" id="delete-cancel" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/css/simpleLightbox.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/admin/css/dropzone.css')); ?>" rel="stylesheet">
    <style>
        .bg-grey-steel .bg-white{
            border: 1px solid #ccc !important;
            padding: 6px 12px;
        }
        table {border:none;}
        hr.style-one {
            border: 0;
            height: 1px;
            background: #333;
            background-image: linear-gradient(to right, #ccc, #333, #ccc);
        }
        .help-block {
            color: #a94442;
        }
        .bg-grey-steel {
            background: #e9edef!important;
        }
        .mt-element-ribbon .ribbon {
            padding: .5em 1em;
            float: left;
            margin: 10px 0 0 -2px;
            clear: left;
            position: relative;
        }
        .mt-element-ribbon {
            position: relative;
            margin-bottom: 30px;
        }
        .mt-element-ribbon .ribbon.ribbon-clip {
            left: -10px;
            margin-left: 0;
        }
        .mt-element-ribbon .ribbon.ribbon-color-danger {
            background-color: #ed6b75;
            color: #fff;
        }
        .mt-element-ribbon .ribbon, .mt-element-ribbon .ribbon.ribbon-color-default, .mt-element-ribbon .ribbon.ribbon-color-default>.ribbon-sub, .mt-element-ribbon .ribbon>.ribbon-sub {
            background-color: #bac3d0;
            color: #384353;
        }
        .mt-element-ribbon .ribbon-content {
            margin: 0;
            padding: 25px;
            clear: both;
        }
        .mt-element-ribbon .ribbon, .mt-element-ribbon .ribbon.ribbon-color-default, .mt-element-ribbon .ribbon.ribbon-color-default>.ribbon-sub, .mt-element-ribbon .ribbon>.ribbon-sub {
            background-color: #bac3d0;
            color: #384353;
        }
        .mt-element-ribbon .ribbon.ribbon-border-hor:after {
            border-top: 1px solid;
            border-bottom: 1px solid;
            border-left: none;
            border-right: none;
            content: '';
            position: absolute;
            top: 5px;
            bottom: 5px;
            left: 0;
            right: 0;
            border-color: #e73d4a;
        }
        b, optgroup, strong {
            font-weight: 800;
        }
        * {
            box-sizing: border-box;
        }

        .row > .column {
            padding: 0 8px;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .column {
            float: left;
            width: 25%;
        }


        /* The Modal (background) */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            padding-top: 100px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: black;
        }

        /* Modal Content */
        .modal-content {
            position: relative;
            background-color: #fefefe;
            margin: auto;
            padding: 0;
            width: 90%;
            max-width: 1200px;
        }

        /* The Close Button */
        .close {
            color: white;
            position: absolute;
            top: 10px;
            right: 25px;
            font-size: 35px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #999;
            text-decoration: none;
            cursor: pointer;
        }

        .mySlides {
            display: none;
        }

        .cursor {
            cursor: pointer;
        }

        /* Next & previous buttons */
        .prev,
        .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -50px;
            color: white;
            font-weight: bold;
            font-size: 20px;
            transition: 0.6s ease;
            border-radius: 0 3px 3px 0;
            user-select: none;
            -webkit-user-select: none;
        }

        /* Position the "next button" to the right */
        .next {
            right: 0;
            border-radius: 3px 0 0 3px;
        }

        /* On hover, add a black background color with a little bit see-through */
        .prev:hover,
        .next:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }

        /* Number text (1/3 etc) */
        .numbertext {
            color: #f2f2f2;
            font-size: 12px;
            padding: 8px 12px;
            position: absolute;
            top: 0;
        }

        img {
            margin-bottom: -4px;
        }

        .caption-container {
            text-align: center;
            background-color: black;
            padding: 2px 16px;
            color: white;
        }

        .demo {
            opacity: 0.6;
        }

        .active,
        .demo:hover {
            opacity: 1;
        }

        img.hover-shadow {
            transition: 0.3s;
        }

        .hover-shadow:hover {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        input[type=file] {
            position: absolute;
            left: 10px;
            top: 0;
            opacity: 0;
            width: 100px;
        }
        img.rotate {
            -webkit-transform: rotate(90deg);
            -moz-transform: rotate(90deg);
            filter: progid:DXImageTransform.Microsoft.BasicImage(rotation=1);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/js/dropzone.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/js/simpleLightbox.min.js')); ?>"></script>
    <script>
        jQuery(document).ready(function(){
            //$('.imageGallery1 a').simpleLightbox();


            $('#btn_submit').on("click", function(e) {
                e.preventDefault();
                var conversation = $("#conversation").val();

                if(conversation == '') {
                    $("#conversation").css('border-color', 'red');
                    return false;
                }
                if($("#demoForm2").find(".dz-preview .dz-image img").length == 0) {
                    $("#demoForm2").submit();
                }
                return false;
            });

            $('.delete-conversation').on('click', function(event) {
                event.stopImmediatePropagation();
                var modal = $("#modal-delete-file");
                var url = $(this).data('url');
                var id = $(this).data('id');
                var csrf = $(this).data('csrf');
                modal.modal('show');

                $("#delete-confirm").unbind().on('click', function (e) {
                    e.stopImmediatePropagation();
                    sendAjax(url, {_token: csrf}, 'POST', function (result) {
                        modal.modal('hide');
                        if(result.success) {
                            $("#conversation_"+id).hide('slow');
                        }
                    });
                });
            });

            $('.delete-file').on('click', function(event) {
                event.stopImmediatePropagation();
                var modal = $("#modal-delete-file");
                var url = $(this).data('url');
                var id = $(this).data('id');
                var csrf = $(this).data('csrf');
                modal.modal('show');

                $("#delete-confirm").unbind().on('click', function (e) {
                    e.stopImmediatePropagation();
                    sendAjax(url, {_token: csrf}, 'POST', function (result) {
                        modal.modal('hide');
                        if(result.success) {
                            $("#conversation_file_"+id).hide('slow');
                        }
                    });
                });
            });


            Dropzone.prototype.defaultOptions.dictRemoveFile = "Fjern fil";
            Dropzone.options.demoForm2 = {
                maxFiles: 10,
                parallelUploads: 10,
                autoProcessQueue: false,
                uploadMultiple: true,
                addRemoveLinks: true,
                dictDefaultMessage: 'Træk og slip her',

                init: function (e) {

                    var myDropzone = this;

                    $('#btn_submit').on("click", function() {
                        var conversation = $("#conversation").val();

                        if(conversation == '') {
                            $("#conversation").css('border-color', 'red');
                            return false;
                        }
                        myDropzone.processQueue(); // Tell Dropzone to process all queued files.
                    });
                    myDropzone.on("complete", function(file, xhr, data) {
                        window.location.reload();
                    });
                    // Event to send your custom data to your server
                    myDropzone.on("sending", function(file, xhr, data) {
                        data.append("conversation", $('#conversation').val());
                    });

                }
            };
        });
        function openModal() {
            document.getElementById('myModal').style.display = "block";
        }

        function closeModal() {
            document.getElementById('myModal').style.display = "none";
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>