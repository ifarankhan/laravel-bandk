<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Create Users </h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">

                    <br />
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" action="<?php echo e(route('users.store')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" id="departments_selected" value="<?php echo e(json_encode(old('departments'))); ?>">
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="name" class="form-control col-md-7 col-xs-12" name="name" value="<?php echo e(old('name')); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="username">Username <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="username" class="form-control col-md-7 col-xs-12" name="username" value="<?php echo e(old('username')); ?>">
                                <?php if($errors->has('username')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="email" class="form-control col-md-7 col-xs-12" name="email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">Password <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="password" class="form-control col-md-7 col-xs-12" name="password" >
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="password">Telefonnummer <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="phone_number" class="form-control col-md-7 col-xs-12" name="phone_number" value="<?php echo e(old('phone_number')); ?>">
                                <?php if($errors->has('phone_number')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('phone_number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Roles
                                <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-9 col-xs-12">
                                <select class="form-control select2" name="roles[]" multiple="multiple" id="roles1">
                                    <option value="">Choose option</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($role->id != 2): ?>
                                            <option value="<?php echo e($role->id); ?>" <?php echo e(old('roles') && in_array($role->id, old('roles')) ? 'selected="selected"' : ''); ?>><?php echo e($role->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('roles')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('roles')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Modules
                                <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-9 col-xs-12">
                                <select class="form-control select2" name="modules[]" multiple="multiple">
                                    <option value="">Choose option</option>
                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($module->id != 3): ?>
                                            <option value="<?php echo e($module->id); ?>" <?php echo e(old('modules') && in_array($module->id, old('modules')) ? 'selected="selected"' : ''); ?>><?php echo e($module->text); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('modules')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('modules')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group" >
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">Customer
                                <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-9 col-xs-12">
                                <select class="form-control" name="customer_id" id="customer_id" data-url="/customer/companies/">
                                    <option value="">Choose option</option>
                                    <?php if(count($customers) > 0): ?>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>" <?php echo e(old('customer_id') == $customer->id ? 'selected="selected"' : ''); ?>><?php echo e($customer->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                                <?php if($errors->has('customer_id')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('customer_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="company_id"><?php echo e(getTranslation('company')); ?><span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-9 col-xs-12">
                                <select class="form-control col-md-7 col-xs-12 select2" multiple="multiple" name="companies[]" id="company_id_id" disabled="disabled" data-url="/customer/departments/grouped/">
                                </select>
                                <?php if($errors->has('company_id')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('company_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="departments"><?php echo e(getTranslation('teams')); ?><span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-9 col-xs-12">
                                <select id='departments' name="departments[]" multiple='multiple'>

                                </select>
                                <?php if($errors->has('departments')): ?>
                                    <span class="help-block" style="color: red;">
                                        <strong><?php echo e($errors->first('departments')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <br />
                        <br />
                        <div class="form-group">
                            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/vendors/select2/dist/css/select2.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/css/multi-select.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/js/jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/js/jquery.multiselect.search.js')); ?>"></script>
    <script>
        jQuery(document).ready(function(){
           jQuery("#roles").on('change', function(){
                var value = jQuery(this).val();

                if(jQuery.inArray("2", value) !== -1) {
                    jQuery("#department_id_div").show();
                    jQuery("#department_id").prop( "disabled", false );
                } else {
                    jQuery("#department_id_div").hide();
                    jQuery("#department_id").prop( "disabled", true );
                }
           });
        });
        $('.select2').select2();
        $('#departments').multiSelect({
            selectableOptgroup: true,
            selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='Search'>",
            selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='Search'>",
            afterInit: function(ms){
                var that = this,
                    $selectableSearch = that.$selectableUl.prev(),
                    $selectionSearch = that.$selectionUl.prev(),
                    selectableSearchString = '#'+that.$container.attr('id')+' .ms-elem-selectable:not(.ms-selected)',
                    selectionSearchString = '#'+that.$container.attr('id')+' .ms-elem-selection.ms-selected';

                that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                    .on('keydown', function(e){
                        if (e.which === 40){
                            that.$selectableUl.focus();
                            return false;
                        }
                    });

                that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                    .on('keydown', function(e){
                        if (e.which == 40){
                            that.$selectionUl.focus();
                            return false;
                        }
                    });
            },
            afterSelect: function(){
                this.qs1.cache();
                this.qs2.cache();
            },
            afterDeselect: function(){
                this.qs1.cache();
                this.qs2.cache();
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>