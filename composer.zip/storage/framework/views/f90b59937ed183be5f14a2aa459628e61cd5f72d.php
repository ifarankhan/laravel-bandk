<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard.index')); ?>"><?php echo e(getTranslation('dashboard')); ?></a></li>
        <li><a href="<?php echo e(route('customer.index')); ?>"><?php echo e(getTranslation('customer')); ?></a></li>
    </ul>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Customer Lists</h2>
                    <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-danger pull-right">Opret</a>
                    <div class="clearfix"></div>
                </div>
                <form action="<?php echo e(route('customer.index')); ?>" method="GET">
                    <div class="row">
                        <div class="form-group form-group-sm col-md-12 col-lg-12">
                            <div class="row">
                                <div class="col-md-4 col-lg-4">
                                    <label for="customer_id">
                                        <?php echo e(getTranslation('customer')); ?>

                                    </label>
                                    <select id="customer_id" class="form-control" name="search[customer_id]" tabindex="-1" aria-hidden="true">
                                        <option value=""><?php echo e(getTranslation('select_customer')); ?></option>
                                        <?php $__currentLoopData = $allCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aCustomer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($aCustomer->id); ?>" <?php echo e((session('customer_id') && session('customer_id') == $aCustomer->id) ? 'selected="selected"' : ''); ?>><?php echo e($aCustomer->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="col-md-4 col-lg-4">
                                    <div class="form-group form-group-sm ">
                                        <label for="customer_id">
                                            &nbsp;
                                        </label>
                                        <div class="">
                                            <button class="btn btn-danger" type="submit"><?php echo e(getTranslation('submit')); ?></button>
                                            <a class="btn btn-success" href="<?php echo e(route('reset.url')); ?>"><?php echo e(getTranslation('reset')); ?></a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
                <div class="x_content">
                    <div class="flash-message">
                        <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Session::has('alert-' . $msg)): ?>
                                <p class="alert alert-<?php echo e($msg); ?>"><?php echo Session::get('alert-' . $msg); ?>  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <table id="datatable1" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th><?php echo e(getTranslation('customer_name')); ?></th>
                            <th><?php echo e(getTranslation('customer_address')); ?></th>
                            <th><?php echo e(getTranslation('customer_city')); ?></th>
                            <th><?php echo e(getTranslation('customer_zip_code')); ?></th>
                            
                            <th width="20%"><?php echo e(getTranslation('actions')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="content_<?php echo e($customer->id); ?>">
                                <td><?php echo e($customer->name); ?></td>
                                <td><?php echo e(($customer->address) ? $customer->address :  ''); ?></td>
                                <td><?php echo e(($customer->city) ? $customer->city :  ''); ?></td>
                                <td><?php echo e(($customer->zip_code) ? $customer->zip_code :  ''); ?></td>
                                
                                <td>
                                    <a href="<?php echo e(route('customer.details', ['id'=> $customer->id])); ?>" class="btn btn-info btn-xs"><?php echo getTranslation('details'); ?> </a>
                                    <a href="<?php echo e(route('customer.edit', ['id'=> $customer->id])); ?>" class="btn btn-success btn-xs"><?php echo getTranslation('edit'); ?></a>
                                    <button data-id="<?php echo e($customer->id); ?>" data-url="<?php echo e(route('customer.delete', ['id'=> $customer->id])); ?>" class="btn btn-danger delete btn-xs" data-toggle="modal" data-target="#modal-delete" data-csrf="<?php echo e(csrf_token()); ?>"><?php echo getTranslation('delete'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?> " rel="stylesheet">
    <link href="<?php echo e(asset('/admin/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?> " rel="stylesheet">
    <style>
        table {
            table-layout: fixed;
            overflow-x: hidden;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-buttons/js/buttons.print.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?> "></script>
    <script src="<?php echo e(asset('/admin/vendors/datatables.net-scroller/js/dataTables.scroller.min.js')); ?> "></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>